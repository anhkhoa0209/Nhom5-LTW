<?php
    require("header.php");
?>

<body>

<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-option">
  <div class="container">
      <div class="row">
          <div class="col-lg-12">

          </div>
      </div>
  </div>
</section>
<!-- Breadcrumb Section End -->

<div class="container bg-light">
  <div class="card">
    <div class="container-fliud">
      <div class="wrapper row">
        <div class="preview col-md-6">
          <div class="preview-pic tab-content">
            <div class="tab-pane active" id="pic-1">
              <img src="img/product/giay1.jpg" alt="" />
            </div>
          </div>
        </div>
        <div class="details col-md-6">
          <h3 class="product-title"> Giày Thời Trang </h3>
          <div class="rating">
            <div class="stars">
              <span class="fa fa-star checked"></span>
              <span class="fa fa-star checked"></span>
              <span class="fa fa-star checked"></span>
              <span class="fa fa-star"></span>
              <span class="fa fa-star"></span>
            </div>
            <span class="review-no">123 đánh giá</span>
          </div>
            <p class="so luong">Số lượng 
              <input aria-label="quantity" class="input-qty" max="10" min="1" name="" type="number" value="1">
            </p>

          <div class="price">1500000 d <span>200.000đ</span></div>
          
          <div>
            <p class="product-description">
              <strong style="font-size: 25px;">Mô tả sản phẩm</strong>
            </br>
        Áo Phông Công Sở Nhận Làm Áo Thun Đồng Phục Công Ty Giá tốt, Chất Lượng, Uy Tín. In may đồng phục Áo thun cty uy tín, chất lượng giá tốt nhất thị trường miễn phí thiết kế. Đúng Hẹn. Đúng Giá. Chiết Khấu Cao. Đúng Chất Lượng. Dịch vụ: Thiết Kế Đẹp, Giao Hàng Tận Nơi, Báo Giá Trong 5 Phút.
          <p class="vote">
            <strong>91%</strong> of người mua hài lòng với sản phẩm này
            <strong>(87 bình chọn)</strong>
          </p>
          <div class="action">
            <a href="giohang.html" target="_blank">
              <button class="add-to-cart btn btn-default btn-info" type="button">
                MUA NGAY
              </button>
            </a>
            <a href="#" target="_blank">
              <button class="like btn btn-defaul btn-info" type="button">
                <span class="fa fa-heart"></span>
              </button>
            </a>
            <button class="btn btn-info text-white" id="btn"><a href="Sanpham.php">quay lại</a></button>
          </div>              
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Js Plugins -->
<script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery.nicescroll.min.js"></script>
    <script src="js/jquery.magnific-popup.min.js"></script>
    <script src="js/jquery.countdown.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
</body>
</div>

<?php
    require("footer.php");
?>